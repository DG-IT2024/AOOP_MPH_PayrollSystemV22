/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package group3_motorph_payrollpaymentsystemv2;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author danilo
 */
public class Main {

    public static void main(String args[]) throws FileNotFoundException, IOException {

        new LoginManager().setVisible(true);

    }

}
